function viewBookings(){
  const u = currentUser();
  if(!u){
    return `<div class="container section empty-state">
      Log in to see your bookings.<br/><br/>
      <button class="btn btn-primary" onclick="nav('auth')">Log in / Register</button>
    </div>`;
  }
  const mine = DB.bookings.filter(b=>b.userId===u.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  const stageLabels = {paid:'Payment Confirmed', accepted:'Provider Accepted', in_progress:'In Progress', completed:'Completed', reviewed:'Reviewed'};
  const stageLabelsCod = {paid:'Booking Confirmed', accepted:'Provider Accepted', in_progress:'In Progress', completed:'Completed', reviewed:'Reviewed'};
  return `
  <div class="container section">
    <div class="eyebrow">Your activity</div>
    <h2 style="margin-top:0;">My Bookings</h2>
    ${mine.length ? mine.map(b=>{
      const p = getProvider(b.providerId);
      const labels = b.paymentMethod==='cod' ? stageLabelsCod : stageLabels;
      return `<div class="card" style="margin-bottom:14px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
        <div>
          <div class="provider-name">${p.name} · ${b.serviceName}</div>
          <div class="provider-meta">${b.date} · ${b.time} · <span class="mono">${b.id}</span> · ${b.paymentMethod==='cod' ? '💵 COD' : '💳 Card'}</div>
        </div>
        <div style="display:flex; align-items:center; gap:12px;">
          <span class="badge-stage dot">${labels[b.stage]}</span>
          <button class="btn btn-ghost btn-sm" onclick="nav('status',{id:'${b.id}'})">View</button>
        </div>
      </div>`;
    }).join('') : `<div class="empty-state">No bookings yet. <a href="#" onclick="nav('search');return false;">Browse services</a> to get started.</div>`}
  </div>`;
}

function viewProfile(){
  const u = currentUser();
  if(!u){
    return `<div class="container section empty-state">
      Log in to view your profile.<br/><br/>
      <button class="btn btn-primary" onclick="nav('auth')">Log in / Register</button>
    </div>`;
  }
  const mine = DB.bookings.filter(b=>b.userId===u.id);
  const completedCount = mine.filter(b=>b.stage==='completed' || b.stage==='reviewed').length;
  const myReviews = [];
  DB.providers.forEach(p=>{
    p.reviews.forEach(r=>{
      const match = mine.find(b=>b.providerId===p.id && b.stage==='reviewed' && r.name===u.name);
      if(match) myReviews.push({provider:p.name, ...r});
    });
  });
  const avgGiven = myReviews.length ? (myReviews.reduce((a,r)=>a+r.rating,0)/myReviews.length).toFixed(1) : '—';

  if(state.editingProfile){
    const previewUrl = typeof state.tempAvatarUrl !== 'undefined' ? state.tempAvatarUrl : (u.avatarUrl || null);
    const cityMandals = mandalsFor(u.city);
    return `
    <div class="container section">
      <div class="eyebrow">Account</div>
      <h2 style="margin-top:0;">Edit Profile</h2>
      <div class="card" style="max-width:520px;">
        <form onsubmit="return saveProfile(event)">
          <div class="form-group">
            <label>Profile photo</label>
            <div class="avatar-edit-row">
              <div id="avatarPreviewWrap">${avatarHtml(u.name, previewUrl, 68, 22)}</div>
              <div style="display:flex; flex-direction:column; gap:8px;">
                <label class="avatar-upload-btn">
                  📷 ${previewUrl ? 'Change photo' : 'Upload photo'}
                  <input type="file" accept="image/*" onchange="handleAvatarFileChange(event)" />
                </label>
                ${previewUrl ? `<button type="button" class="avatar-remove-btn" onclick="removeAvatarPreview()">Remove photo</button>` : ''}
              </div>
            </div>
          </div>
          <div class="form-group">
            <label>Full name</label>
            <input class="field" name="name" value="${u.name||''}" required />
          </div>
          <div class="form-group">
            <label>Mobile number</label>
            <input class="field" type="tel" name="phone" value="${u.phone||''}" pattern="[0-9]{10}" placeholder="10-digit mobile number" required />
          </div>
          <div class="form-group">
            <label>Street / House No.</label>
            <input class="field" name="street" value="${u.street||''}" placeholder="e.g. 12-34, Ring Road" />
          </div>
          <div class="form-grid-2">
            <div class="form-group">
              <label>City</label>
              <select class="field" name="city" id="profileCity" required onchange="renderMandalOptions(this.value,'profileMandal')">
                ${AP_CITIES.map(c=>`<option value="${c}" ${u.city===c?'selected':''}>${c}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label>Mandal</label>
              <select class="field" name="mandal" id="profileMandal">
                ${cityMandals.length ? cityMandals.map(m=>`<option value="${m}" ${u.mandal===m?'selected':''}>${m}</option>`).join('') : `<option value="">Select city first</option>`}
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Pincode</label>
            <input class="field" name="pincode" value="${u.pincode||''}" placeholder="e.g. 520010" pattern="[0-9]{6}" maxlength="6" />
          </div>
          <div style="display:flex; gap:10px;">
            <button class="btn btn-primary" type="submit">Save Changes</button>
            <button class="btn btn-ghost" type="button" onclick="state.editingProfile=false; state.tempAvatarUrl=undefined; render();">Cancel</button>
          </div>
        </form>
      </div>
    </div>`;
  }

  return `
  <div class="container section">
    <div class="eyebrow">Account</div>
    <h2 style="margin-top:0;">My Profile</h2>
    <div class="card">
      <div class="profile-header">
        ${avatarHtml(u.name, u.avatarUrl, 64, 20)}
        <div>
          <h3 style="margin:0 0 4px;">${u.name}</h3>
          <div class="provider-meta">✉️ ${u.email}</div>
          <div class="provider-meta">📞 ${u.phone || 'Not provided'}</div>
          <div class="provider-meta">📍 ${[u.street, u.mandal, u.city].filter(Boolean).join(', ') || 'Not set'}${u.pincode ? ' - '+u.pincode : ''}${(!u.street && !u.mandal && !u.city) ? ', Andhra Pradesh' : ''}</div>
          <div class="provider-meta">Member since ${u.joinedAt || '—'}</div>
        </div>
      </div>
      <div class="profile-stats">
        <div class="stat-box"><div class="num">${mine.length}</div><div class="lbl">Total Bookings</div></div>
        <div class="stat-box"><div class="num">${completedCount}</div><div class="lbl">Completed Services</div></div>
        <div class="stat-box"><div class="num">${myReviews.length}</div><div class="lbl">Reviews Given</div></div>
        <div class="stat-box"><div class="num">${avgGiven}</div><div class="lbl">Avg. Rating Given</div></div>
      </div>
      <button class="btn btn-ghost" style="margin-top:20px;" onclick="state.editingProfile=true; state.tempAvatarUrl=(currentUser().avatarUrl||null); render();">Edit Profile</button>
    </div>

    <div class="card" style="margin-top:18px;">
      <h3 style="margin-top:0;">My Reviews</h3>
      ${myReviews.length ? myReviews.map(r=>`
        <div class="review-item">
          <div style="display:flex; justify-content:space-between;">
            <strong>${r.provider}</strong>
            <span class="stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</span>
          </div>
          <div class="provider-meta" style="margin:4px 0;">${r.date}</div>
          <div>${r.comment}</div>
        </div>
      `).join('') : `<div class="provider-meta">You have not left any reviews yet.</div>`}
    </div>
  </div>`;
}

function handleAvatarFileChange(e){
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  if(!file.type.startsWith('image/')){
    toast('Please choose an image file');
    return;
  }
  if(file.size > 2*1024*1024){
    toast('Please choose an image under 2MB');
    return;
  }
  const reader = new FileReader();
  reader.onload = function(ev){
    state.tempAvatarUrl = ev.target.result;
    render();
  };
  reader.readAsDataURL(file);
}

function removeAvatarPreview(){
  state.tempAvatarUrl = null;
  render();
}

function saveProfile(e){
  e.preventDefault();
  const f = e.target;
  const u = currentUser();
  u.name = f.name.value.trim() || u.name;
  u.phone = f.phone.value.trim();
  u.street = f.street.value.trim();
  u.city = f.city.value;
  u.mandal = f.mandal.value;
  u.pincode = f.pincode.value.trim();
  u.avatarUrl = typeof state.tempAvatarUrl !== 'undefined' ? state.tempAvatarUrl : (u.avatarUrl || null);

  /* Keep a linked worker listing's public name, phone, and photo in sync with the profile,
     since customers see that listing directly. */
  if(u.role === 'worker'){
    const p = DB.providers.find(pr=>pr.ownerId===u.id);
    if(p){
      p.name = u.name;
      p.phone = u.phone;
      p.avatarUrl = u.avatarUrl;
    }
  }

  state.editingProfile = false;
  state.tempAvatarUrl = undefined;
  toast('Profile updated');
  render();
  return false;
}

function myProviderProfile(){
  const u = currentUser();
  if(!u || u.role !== 'worker') return null;
  return DB.providers.find(p=>p.ownerId===u.id) || null;
}

function viewWorkerDashboard(){
  const u = currentUser();
  if(!u || u.role !== 'worker'){
    return `<div class="container section empty-state">
      This dashboard is for registered workers.<br/><br/>
      <button class="btn btn-primary" onclick="nav('auth')">Log in / Register as a worker</button>
    </div>`;
  }
  const p = myProviderProfile();
  const jobsNearby = DB.bookings.filter(b=>b.providerId===p.id);
  const c = catInfo(p.category);

  const nearbyCustomers = DB.users
    .filter(cu=>cu.role !== 'worker' && cu.city === p.area)
    .slice(0,6);

  /* Active in-progress job for this worker gets its own live tracking card so the worker
     can see exactly where the customer's address is relative to them, matching the customer's view. */
  const activeJob = jobsNearby.find(b=>b.stage==='in_progress');
  let workerTrackingWidget = '';
  if(activeJob){
    const eta = typeof activeJob.trackingETA === 'number' ? activeJob.trackingETA : 0;
    const initial = activeJob.trackingETAInitial || 15;
    const pct = Math.min(100, Math.round(((initial - eta) / initial) * 100));
    const arrived = eta <= 0;
    const cCenter = CITY_COORDS[p.area] || [16.5,80.6];
    const custLat = jitter(cCenter[0], activeJob.id+'custlat');
    const custLng = jitter(cCenter[1], activeJob.id+'custlng');
    const distKm = distanceKm(p.lat, p.lng, custLat, custLng).toFixed(1);
    workerTrackingWidget = `
    <div class="card" style="margin-top:18px;">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
        <span class="live-badge"><span class="live-dot"></span> En route to customer</span>
        <span class="provider-meta mono">${activeJob.id} · ${distKm} km</span>
      </div>
      <p class="provider-meta" style="margin:8px 0 0;">Delivering: <strong>${activeJob.serviceName}</strong> to ${activeJob.address}${activeJob.paymentMethod==='cod' ? ` · 💵 collect ${fmt(activeJob.servicePrice)} cash on arrival` : ' · 💳 already paid online'}</p>
      <div class="map-box" style="margin-top:14px; height:220px;">
        <div class="map-legend">
          <div class="lg-row"><span class="lg-dot" style="background:var(--accent-2);"></span> You (worker)</div>
          <div class="lg-row"><span class="lg-dot" style="background:var(--accent);"></span> Customer</div>
        </div>
        <iframe src="${mapDirectionsEmbedUrl(p.lat, p.lng, custLat, custLng)}" loading="lazy" title="Route to customer"></iframe>
      </div>
      <div class="track-path">
        <span class="track-endpoint" style="left:-4px;">🔧</span>
        <span class="track-endpoint-label" style="left:-8px;">You</span>
        <div class="track-fill" style="width:${pct}%;"></div>
        <div class="track-marker" style="left:${pct}%;">🚗</div>
        <span class="track-endpoint" style="right:-4px;">🏠</span>
        <span class="track-endpoint-label" style="right:-16px;">Customer</span>
      </div>
      <div class="track-legend">
        <span>${pct}% of the way</span>
        <span>${arrived ? 'Arrived at customer' : distKm + ' km to go'}</span>
      </div>
      <div style="text-align:center; margin-top:14px;">
        <button class="btn btn-primary btn-sm" onclick="nav('status',{id:'${activeJob.id}'})">Open Job Details</button>
      </div>
    </div>`;
  }

  return `
  <div class="container section">
    <div class="eyebrow">Worker dashboard</div>
    <h2 style="margin-top:0;">Welcome, ${u.name.split(' ')[0]} <span class="worker-badge">✓ Verified Pro</span></h2>

    <div class="card" style="margin-bottom:18px;">
      <div class="provider-top" style="margin-bottom:10px;">
        ${avatarHtml(p.name, p.avatarUrl, 48, 15)}
        <div>
          <div class="provider-name">${p.name}</div>
          <div class="provider-meta">${c.icon} ${c.name} · ${p.mandal}, ${p.area} - ${p.pincode}</div>
        </div>
      </div>
      <button class="btn btn-ghost btn-sm" style="margin-bottom:10px;" onclick="nav('profile')">Edit Profile / Photo</button>
      <p class="provider-meta">${p.bio}</p>
      <div class="profile-stats">
        <div class="stat-box"><div class="num">${jobsNearby.length}</div><div class="lbl">Bookings Received</div></div>
        <div class="stat-box"><div class="num">${reviewCountDisplay(p)}</div><div class="lbl">Total Reviews</div></div>
        <div class="stat-box"><div class="num">${avgRating(p) ? avgRating(p).toFixed(1) : '—'}</div><div class="lbl">Avg. Rating</div></div>
        <div class="stat-box"><div class="num">${p.services.length}</div><div class="lbl">Services Listed</div></div>
      </div>
    </div>

    ${workerTrackingWidget}

    <div class="grid grid-2" style="margin-top:${workerTrackingWidget ? '18px' : '0'};">
      <div class="card">
        <h3 style="margin-top:0;">Your listed services</h3>
        ${p.services.map(s=>`<div class="summary-row"><span>${s.name}</span><span class="price-tag">${fmt(s.price)}</span></div>`).join('')}
        <button class="btn btn-ghost btn-block" style="margin-top:14px;" onclick="nav('provider',{id:'${p.id}'})">View Public Profile</button>
      </div>
      <div class="card">
        <h3 style="margin-top:0;">Recent bookings</h3>
        ${jobsNearby.length ? jobsNearby.slice(0,5).map(b=>`
          <div class="summary-row"><span>${b.serviceName} · ${b.date}${b.paymentMethod==='cod' ? ' · 💵 COD' : ' · 💳 Card'}</span><span class="badge-stage dot">${b.stage}</span></div>
        `).join('') : `<div class="provider-meta">No bookings yet. Customers will appear here once they book you.</div>`}
      </div>
    </div>

    <div class="card" style="margin-top:18px;">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <h3 style="margin:0;">Find customers near you</h3>
        <span class="live-badge" style="color:var(--accent-2);"><span class="live-dot" style="background:var(--accent-2);"></span> ${p.area}</span>
      </div>
      <p class="provider-meta">Browse ${state.filterCategory||c.name.toLowerCase()} requests and household areas around your service radius in ${p.mandal}.</p>
      <div class="map-box">
        <iframe src="${mapSearchEmbedUrl(c.name + ' service requests near ' + p.mandal + ' ' + p.area + ' Andhra Pradesh', 13)}" loading="lazy" title="Customers near you"></iframe>
      </div>
      ${nearbyCustomers.length ? `
        <div style="margin-top:14px;">
          <div class="provider-meta" style="margin-bottom:8px;">Registered customers in ${p.area}:</div>
          ${nearbyCustomers.map(cu=>`<div class="summary-row"><span>${cu.name}</span><span class="provider-meta">${cu.mandal||''}</span></div>`).join('')}
        </div>` : `<div class="provider-meta" style="margin-top:12px;">No registered customers in your city yet — check back soon.</div>`}
    </div>
  </div>`;
}

function viewFindMap(){
  const results = DB.providers.filter(p=>{
    const matchCat = !state.filterCategory || p.category === state.filterCategory;
    const matchLoc = !state.filterLocation || p.area.toLowerCase().includes(state.filterLocation.toLowerCase());
    const matchRating = !state.filterRating || avgRating(p) >= Number(state.filterRating);
    return matchCat && matchLoc && matchRating;
  });
  const query = [state.filterCategory ? catInfo(state.filterCategory).name : 'local services', state.filterLocation || 'Andhra Pradesh'].join(' near ');
  return `
  <div class="container section">
    <div class="eyebrow">Map view</div>
    <h2 style="margin-top:0;">Find a worker near you</h2>
    <div class="card" style="display:flex; gap:12px; flex-wrap:wrap; margin-bottom:18px;">
      <select class="field" style="max-width:220px;" onchange="state.filterCategory=this.value; render();">
        <option value="">All services</option>
        ${categories.map(c=>`<option value="${c.id}" ${state.filterCategory===c.id?'selected':''}>${c.icon} ${c.name}</option>`).join('')}
      </select>
      <select class="field" style="max-width:220px;" onchange="state.filterLocation=this.value; render();">
        <option value="">All Andhra Pradesh</option>
        ${AP_CITIES.map(c=>`<option value="${c}" ${state.filterLocation===c?'selected':''}>${c}</option>`).join('')}
      </select>
      <select class="field" style="max-width:200px;" onchange="state.filterRating=this.value; render();">
        <option value="">All ratings</option>
        <option value="4" ${state.filterRating==='4'?'selected':''}>★★★★ & up (4+)</option>
        <option value="3" ${state.filterRating==='3'?'selected':''}>★★★ & up (3+)</option>
        <option value="2" ${state.filterRating==='2'?'selected':''}>★★ & up (2+)</option>
        <option value="1" ${state.filterRating==='1'?'selected':''}>★ & up (1+)</option>
      </select>
    </div>
    <div class="map-box" style="height:360px; margin-bottom:20px;">
      <iframe src="${mapSearchEmbedUrl(query, state.filterLocation?13:8)}" loading="lazy" title="Workers near you"></iframe>
    </div>
    <h3>${results.length} pro${results.length===1?'':'s'} found</h3>
    <div class="grid grid-3">
      ${results.map(p=>`
        <div class="card provider-card">
          <div class="provider-top">
            ${avatarHtml(p.name, p.avatarUrl, 48, 15)}
            <div>
              <div class="provider-name">${p.name}</div>
              <div class="provider-meta">${catInfo(p.category).icon} ${p.mandal}, ${p.area}</div>
            </div>
          </div>
          <div>${starsDisplay(avgRating(p))} <span class="provider-meta">(${reviewCountDisplay(p)})</span></div>
          <button class="btn btn-ghost btn-block" onclick="nav('provider',{id:'${p.id}'})">View Profile</button>
        </div>
      `).join('')}
    </div>
  </div>`;
}

