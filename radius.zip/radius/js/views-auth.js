function viewAuth(){
  return `
  <div class="container section">
    <div class="card auth-card" style="max-width:${state.authTab==='register' && state.authRole==='worker' ? '560px' : '420px'};">
      <div class="tabs">
        <button class="tab-btn ${state.authTab==='login'?'active':''}" onclick="state.authTab='login'; render();">Log In</button>
        <button class="tab-btn ${state.authTab==='register'?'active':''}" onclick="state.authTab='register'; render();">Register</button>
      </div>
      ${state.authTab==='login' ? `
        <form onsubmit="return handleLogin(event)">
          <div class="form-group">
            <label>Email</label>
            <input class="field" type="email" name="email" required />
          </div>
          <div class="form-group">
            <label>Password</label>
            <input class="field" type="password" name="password" required />
          </div>
          <button class="btn btn-primary btn-block" type="submit">Log In</button>
        </form>
      ` : `
        <div class="role-toggle">
          <button type="button" class="${state.authRole==='customer'?'active':''}" onclick="state.authRole='customer'; render();">I need a service</button>
          <button type="button" class="${state.authRole==='worker'?'active':''}" onclick="state.authRole='worker'; render();">I'm a worker / pro</button>
        </div>
        ${state.authRole==='customer' ? viewCustomerRegisterForm() : viewWorkerRegisterForm()}
      `}
    </div>
  </div>`;
}

function viewCustomerRegisterForm(){
  return `
  <form onsubmit="return handleRegister(event)">
    <div class="form-group">
      <label>Full name</label>
      <input class="field" name="name" required />
    </div>
    <div class="form-group">
      <label>Email</label>
      <input class="field" type="email" name="email" required />
    </div>
    <div class="form-group">
      <label>Phone number</label>
      <input class="field" type="tel" name="phone" placeholder="10-digit mobile number" pattern="[0-9]{10}" required />
    </div>
    <div class="form-group">
      <label>City</label>
      <select class="field" name="city" required onchange="renderMandalOptions(this.value,'mandal')">
        <option value="">Select your city</option>
        ${AP_CITIES.map(c=>`<option value="${c}">${c}</option>`).join('')}
      </select>
    </div>
    <div class="form-group">
      <label>Mandal</label>
      <select class="field" name="mandal" id="mandal">
        <option value="">Select city first</option>
      </select>
    </div>
    <div class="form-group">
      <label>Password</label>
      <input class="field" type="password" name="password" required minlength="4" />
    </div>
    <button class="btn btn-primary btn-block" type="submit">Create Account</button>
  </form>`;
}

function viewWorkerRegisterForm(){
  return `
  <form onsubmit="return handleWorkerRegister(event)">
    <div class="form-group">
      <label>Full name</label>
      <input class="field" name="name" required />
    </div>
    <div class="form-grid-2">
      <div class="form-group">
        <label>Email</label>
        <input class="field" type="email" name="email" required />
      </div>
      <div class="form-group">
        <label>Phone number</label>
        <input class="field" type="tel" name="phone" placeholder="10-digit mobile number" pattern="[0-9]{10}" required />
      </div>
    </div>

    <div class="form-group">
      <label>Street / House No.</label>
      <input class="field" name="street" placeholder="e.g. 5-21, Market Lane" required />
    </div>
    <div class="form-grid-2">
      <div class="form-group">
        <label>City</label>
        <select class="field" name="city" id="workerCity" required onchange="renderMandalOptions(this.value,'workerMandal')">
          <option value="">Select city</option>
          ${AP_CITIES.map(c=>`<option value="${c}">${c}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Mandal</label>
        <select class="field" name="mandal" id="workerMandal" required>
          <option value="">Select city first</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label>Pincode</label>
      <input class="field" name="pincode" placeholder="e.g. 520010" pattern="[0-9]{6}" maxlength="6" required />
    </div>

    <div class="form-group">
      <label>Service category</label>
      <div class="chip-select">
        ${categories.map(c=>`<span class="chip ${state.workerCategories.includes(c.id)?'selected':''}" onclick="toggleWorkerCategory('${c.id}')">${c.icon} ${c.name}</span>`).join('')}
      </div>
    </div>

    <div class="form-group">
      <label>Short bio / experience</label>
      <input class="field" name="bio" placeholder="e.g. 6 years experience, available all week" required />
    </div>

    <div class="form-group">
      <label>Services you offer & pricing</label>
      <div id="workerServiceRows">
        ${state.workerServiceRows.map((row,i)=>`
          <div class="service-row-input">
            <input class="field" placeholder="Service name" value="${row.name}" oninput="state.workerServiceRows[${i}].name=this.value" />
            <input class="field" style="max-width:120px;" type="number" min="0" placeholder="Price ₹" value="${row.price}" oninput="state.workerServiceRows[${i}].price=this.value" />
            <button type="button" class="remove-row" onclick="removeWorkerServiceRow(${i})" title="Remove">×</button>
          </div>
        `).join('')}
      </div>
      <button type="button" class="btn btn-ghost btn-sm" onclick="addWorkerServiceRow()">+ Add another service</button>
    </div>

    <div class="form-group">
      <label>Password</label>
      <input class="field" type="password" name="password" required minlength="4" />
    </div>
    <button class="btn btn-primary btn-block" type="submit">Register as a Worker</button>
    <p class="provider-meta" style="text-align:center; margin-top:10px;">Your profile will be listed for customers to find and book, with a map pin at your service location.</p>
  </form>`;
}

function renderMandalOptions(city, selectId){
  const sel = document.getElementById(selectId);
  if(!sel) return;
  const mandals = mandalsFor(city);
  sel.innerHTML = mandals.length
    ? mandals.map(m=>`<option value="${m}">${m}</option>`).join('')
    : `<option value="">No mandals found</option>`;
}

function toggleWorkerCategory(id){
  const idx = state.workerCategories.indexOf(id);
  if(idx === -1) state.workerCategories.push(id); else state.workerCategories.splice(idx,1);
  render();
}

function addWorkerServiceRow(){
  state.workerServiceRows.push({name:'',price:''});
  render();
}
function removeWorkerServiceRow(i){
  state.workerServiceRows.splice(i,1);
  if(!state.workerServiceRows.length) state.workerServiceRows.push({name:'',price:''});
  render();
}

function postLoginRedirect(){
  if(state.redirect){
    const {view,params} = state.redirect;
    state.redirect = null;
    nav(view, params);
  } else {
    nav('home');
  }
}

function handleLogin(e){
  e.preventDefault();
  const f = e.target;
  const email = f.email.value.trim().toLowerCase();
  const user = DB.users.find(u=>u.email===email && u.password===f.password.value);
  if(!user){
    toast('Invalid email or password');
    return false;
  }
  DB.currentUserId = user.id;
  toast('Welcome back, ' + user.name.split(' ')[0] + '!');
  postLoginRedirect();
  return false;
}

function handleRegister(e){
  e.preventDefault();
  const f = e.target;
  const email = f.email.value.trim().toLowerCase();
  if(DB.users.some(u=>u.email===email)){
    toast('An account with that email already exists');
    return false;
  }
  const user = {
    id:'u'+(DB.users.length+1),
    role:'customer',
    name:f.name.value.trim(),
    email,
    phone:f.phone.value.trim(),
    city:f.city.value,
    mandal:f.mandal.value,
    password:f.password.value,
    joinedAt:new Date().toISOString().split('T')[0],
  };
  DB.users.push(user);
  DB.currentUserId = user.id;
  toast('Account created — welcome, ' + user.name.split(' ')[0] + '!');
  postLoginRedirect();
  return false;
}

function handleWorkerRegister(e){
  e.preventDefault();
  const f = e.target;
  const email = f.email.value.trim().toLowerCase();
  if(DB.users.some(u=>u.email===email)){
    toast('An account with that email already exists');
    return false;
  }
  if(!state.workerCategories.length){
    toast('Please select at least one service category');
    return false;
  }
  const services = state.workerServiceRows
    .filter(r=>r.name.trim() && r.price !== '')
    .map(r=>({name:r.name.trim(), price:Number(r.price)}));
  if(!services.length){
    toast('Please add at least one service with a price');
    return false;
  }
  const city = f.city.value;
  const c = CITY_COORDS[city] || [16.5,80.6];
  const category = state.workerCategories[0];

  const user = {
    id:'u'+(DB.users.length+1),
    role:'worker',
    name:f.name.value.trim(),
    email,
    phone:f.phone.value.trim(),
    city,
    mandal:f.mandal.value,
    password:f.password.value,
    joinedAt:new Date().toISOString().split('T')[0],
  };
  DB.users.push(user);
  DB.currentUserId = user.id;

  const providerId = 'p' + (DB.providers.length + 1) + '_' + user.id;
  const provider = {
    id: providerId,
    name: user.name,
    phone: user.phone,
    category,
    categories: state.workerCategories.slice(),
    area: city,
    street: f.street.value.trim(),
    mandal: f.mandal.value,
    pincode: f.pincode.value.trim(),
    lat: jitter(c[0], providerId+'lat'),
    lng: jitter(c[1], providerId+'lng'),
    bio: f.bio.value.trim(),
    reviewCount: 0,
    services,
    reviews: [],
    ownerId: user.id,
  };
  DB.providers.push(provider);

  state.workerCategories = [];
  state.workerServiceRows = [{name:'',price:''}];
  toast('Worker profile created — you are now listed for customers to find!');
  nav('worker-dashboard');
  return false;
}

function logout(){
  DB.currentUserId = null;
  toast('Logged out');
  nav('home');
}

