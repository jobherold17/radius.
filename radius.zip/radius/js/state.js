/* ---------------- App state ---------------- */
let route = {view:'home', params:{}};
let history = [];
let state = {
  filterCategory:'',
  filterLocation:'',
  filterQuery:'',
  filterRating:'',
  sortBy:'rating',
  authTab:'login',
  redirect:null,
  bookingDraft:null,
  processingPayment:false,
  reviewStars:0,
  editingProfile:false,
  authRole:'customer',
  workerCategories:[],
  workerServiceRows:[{name:'',price:''}],
  customerLoc:null,
  paymentMethod:'card',
  showNavSuggest:false,
  showHomeSuggest:false,
};

/* Live tracking ticker — decrements ETA on any in_progress booking every few seconds */
setInterval(()=>{
  let changed = false;
  DB.bookings.forEach(b=>{
    if(b.stage === 'in_progress' && typeof b.trackingETA === 'number' && b.trackingETA > 0){
      b.trackingETA -= 1;
      changed = true;
    }
  });
  if(changed && route.view === 'status'){ render(); }
}, 4000);

function nav(view, params={}, opts={}){
  if(!opts.skipHistory){
    history.push(route);
  }
  route = {view, params};
  state.showNavSuggest = false;
  state.showHomeSuggest = false;
  window.scrollTo({top:0, behavior:'smooth'});
  render();
}

function goBack(){
  if(history.length === 0){
    nav('home', {}, {skipHistory:true});
    return;
  }
  route = history.pop();
  window.scrollTo({top:0, behavior:'smooth'});
  render();
}

function toast(msg){
  const root = document.getElementById('toast-root');
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  root.appendChild(el);
  requestAnimationFrame(()=>el.classList.add('show'));
  setTimeout(()=>{ el.classList.remove('show'); setTimeout(()=>el.remove(), 300); }, 2600);
}

