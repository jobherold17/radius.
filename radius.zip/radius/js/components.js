/* ---------------- Shared components ---------------- */
function navbar(){
  const u = currentUser();
  const link = (view,label) => `<button class="nav-link ${route.view===view?'active':''}" onclick="nav('${view}')">${label}</button>`;
  const canGoBack = history.length > 0;
  return `
  <div class="navbar">
    <div class="navbar-inner">
      <div class="navbar-left">
        <button class="back-btn" title="Go back" onclick="goBack()" ${canGoBack ? '' : 'disabled'}>←</button>
        <div class="logo" onclick="nav('home')">
          <span class="logo-mark"></span> Radius
        </div>
      </div>
      <form class="nav-search" onsubmit="return navSearch(event)">
        <input type="text" placeholder="Search services, e.g. plumber, tutor..." id="navSearchInput"
          value="${state.filterQuery || ''}"
          oninput="onNavSearchInput(this.value)"
          onfocus="onNavSearchInput(this.value)"
          onblur="hideSuggestSoon('nav')" autocomplete="off" />
        <button type="submit" title="Search">🔍</button>
        <div class="search-suggest" id="navSuggestDropdown" style="display:${state.showNavSuggest?'block':'none'};">
          ${state.showNavSuggest ? suggestDropdown('navSearchInput','navSuggestDropdown', state.filterQuery) : ''}
        </div>
      </form>
      <div class="nav-links">
        ${link('home','Home')}
        ${link('search','Search')}
        ${link('find-map','Map')}
        ${u && u.role === 'worker' ? link('worker-dashboard','Dashboard') : ''}
        ${u && u.role !== 'worker' ? link('bookings','My Bookings') : ''}
        ${u ? link('profile','My Profile') : ''}
        ${u
          ? `<button class="btn btn-ghost btn-sm" onclick="logout()">Log out</button>`
          : `<button class="btn btn-primary btn-sm" onclick="nav('auth')">Log in / Register</button>`
        }
      </div>
    </div>
  </div>`;
}

function navSearch(e){
  e.preventDefault();
  const val = document.getElementById('navSearchInput').value.trim();
  state.filterQuery = val;
  nav('search');
  return false;
}

function footer(){
  return `<div class="footer container">Radius — Local Service Finder. Search and book trusted professionals near you.</div>`;
}

function orbitScene(){
  const icons = categories.slice(0,8);
  const step = 360/icons.length;
  const iconsHtml = icons.map((c,i)=>{
    const angle = i*step;
    return `<div class="orbit-icon" style="transform:rotateY(${angle}deg) translateZ(150px);">${c.icon}</div>`;
  }).join('');
  return `
  <div class="orbit-scene">
    <div class="pulse-ring"></div>
    <div class="pulse-ring d2"></div>
    <div class="pulse-ring d3"></div>
    <div class="orbit-ring">${iconsHtml}</div>
    <div class="orbit-center"></div>
  </div>`;
}

function timeline(stage){
  const stages = [
    {key:'paid', label:'Payment Confirmed'},
    {key:'accepted', label:'Provider Accepted'},
    {key:'in_progress', label:'In Progress'},
    {key:'completed', label:'Completed'},
    {key:'reviewed', label:'Reviewed'},
  ];
  const idx = stages.findIndex(s=>s.key===stage);
  return `<div class="timeline">
    ${stages.map((s,i)=>{
      let cls = '';
      if(i < idx) cls = 'done';
      else if(i === idx) cls = 'active';
      return `<div class="timeline-node ${cls}">
        <div class="timeline-dot"></div>
        <div class="timeline-label">${s.label}</div>
      </div>`;
    }).join('')}
  </div>`;
}

