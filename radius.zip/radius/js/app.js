/* ---------------- Render ---------------- */
function render(){
  let body = '';
  switch(route.view){
    case 'home': body = viewHome(); break;
    case 'search': body = viewSearch(); break;
    case 'provider': body = viewProvider(route.params); break;
    case 'booking': body = viewBooking(route.params); break;
    case 'payment': body = viewPayment(route.params); break;
    case 'status': body = viewStatus(route.params); break;
    case 'bookings': body = viewBookings(); break;
    case 'profile': body = viewProfile(); break;
    case 'auth': body = viewAuth(); break;
    case 'worker-dashboard': body = viewWorkerDashboard(); break;
    case 'find-map': body = viewFindMap(); break;
    default: body = viewHome();
  }
  document.getElementById('app').innerHTML = navbar() + body + footer();
}

render();

