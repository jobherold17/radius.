/* ---------------- Search suggestion engine ---------------- */
/* Returns up to `limit` matches across provider names, categories, areas, and individual services,
   ranked with services/category-name matches first since those are what people usually type. */
function getSearchSuggestions(qRaw, limit){
  const q = (qRaw||'').trim().toLowerCase();
  if(!q) return [];
  const results = [];

  categories.forEach(c=>{
    if(c.name.toLowerCase().includes(q)){
      results.push({type:'category', icon:c.icon, title:c.name, sub:'Browse category', rank:0, catId:c.id});
    }
  });

  DB.providers.forEach(p=>{
    const c = catInfo(p.category);
    p.services.forEach(s=>{
      if(s.name.toLowerCase().includes(q)){
        results.push({type:'service', icon:c.icon, title:s.name, sub:p.name+' · '+p.area, price:s.price, rank:1, providerId:p.id});
      }
    });
    if(p.name.toLowerCase().includes(q)){
      results.push({type:'provider', icon:c.icon, title:p.name, sub:c.name+' · '+p.area, rank:2, providerId:p.id});
    }
    if(!p.services.some(s=>s.name.toLowerCase().includes(q)) && !p.name.toLowerCase().includes(q) && p.area.toLowerCase().includes(q)){
      results.push({type:'area', icon:'📍', title:p.area, sub:c.name+' pros nearby', rank:3, area:p.area});
    }
  });

  const seen = new Set();
  const deduped = [];
  for(const r of results){
    const key = r.type+'|'+r.title+'|'+(r.providerId||r.area||r.catId||'');
    if(seen.has(key)) continue;
    seen.add(key);
    deduped.push(r);
  }
  deduped.sort((a,b)=>a.rank-b.rank);
  return deduped.slice(0, limit||8);
}

function suggestDropdown(inputId, dropdownId, value){
  const items = getSearchSuggestions(value, 8);
  if(!items.length){
    return `<div class="search-suggest-empty">No matching services or pros yet</div>`;
  }
  return items.map(it=>{
    const clickAction = it.type==='category' ? `chooseSuggestCategory('${it.catId}')`
      : (it.type==='provider'||it.type==='service') ? `chooseSuggestProvider('${it.providerId}')`
      : `chooseSuggestArea('${it.area}')`;
    return `<div class="search-suggest-item" onclick="${clickAction}">
      <span class="ssi-icon">${it.icon}</span>
      <div class="ssi-main">
        <div class="ssi-title">${it.title}</div>
        <div class="ssi-sub">${it.sub}</div>
      </div>
      ${it.price ? `<span class="ssi-price">${fmt(it.price)}</span>` : ''}
    </div>`;
  }).join('');
}

function chooseSuggestCategory(catId){
  state.filterCategory = catId;
  state.filterQuery = '';
  state.showNavSuggest = false;
  state.showHomeSuggest = false;
  nav('search');
}
function chooseSuggestProvider(providerId){
  state.showNavSuggest = false;
  state.showHomeSuggest = false;
  nav('provider',{id:providerId});
}
function chooseSuggestArea(area){
  state.filterLocation = area;
  state.filterQuery = '';
  state.showNavSuggest = false;
  state.showHomeSuggest = false;
  nav('search');
}

function onNavSearchInput(val){
  state.filterQuery = val;
  state.showNavSuggest = val.trim().length > 0;
  const dd = document.getElementById('navSuggestDropdown');
  if(dd){
    dd.innerHTML = suggestDropdown('navSearchInput','navSuggestDropdown', val);
    dd.style.display = state.showNavSuggest ? 'block' : 'none';
  }
}
function onHomeSearchInput(val){
  state.filterQuery = val;
  state.showHomeSuggest = val.trim().length > 0;
  const dd = document.getElementById('homeSuggestDropdown');
  if(dd){
    dd.innerHTML = suggestDropdown('homeQuery','homeSuggestDropdown', val);
    dd.style.display = state.showHomeSuggest ? 'block' : 'none';
  }
}
function hideSuggestSoon(which){
  setTimeout(()=>{
    if(which==='nav') state.showNavSuggest = false; else state.showHomeSuggest = false;
    const dd = document.getElementById(which==='nav' ? 'navSuggestDropdown' : 'homeSuggestDropdown');
    if(dd) dd.style.display = 'none';
  }, 180);
}

