function viewProvider(params){
  const p = getProvider(params.id);
  if(!p) return `<div class="container section empty-state">Provider not found. <a href="#" onclick="nav('search');return false;">Back to search</a></div>`;
  const c = catInfo(p.category);
  return `
  <div class="container section">
    <div class="card" style="margin-bottom:24px;">
      <div class="provider-top" style="margin-bottom:14px;">
        ${avatarHtml(p.name, p.avatarUrl, 64, 20)}
        <div>
          <h2 style="margin:0 0 4px;">${p.name}</h2>
          <div class="provider-meta">${c.icon} ${c.name} · ${p.area}, Andhra Pradesh</div>
          <div style="margin-top:6px;">${starsDisplay(avgRating(p))} <span class="provider-meta">${avgRating(p).toFixed(1)} (${reviewCountDisplay(p)} reviews)</span></div>
        </div>
      </div>
      <p style="color:var(--text-muted);">${p.bio}</p>
      <p class="provider-meta">📞 <a href="tel:${p.phone.replace(/\s/g,'')}">${p.phone}</a></p>
      <p class="provider-meta">📍 ${p.street}, ${p.mandal}, ${p.area} - ${p.pincode}</p>
      ${p.category === 'phone'
        ? `<div class="card" style="background:var(--surface-2); border-color:var(--accent); padding:12px 14px; margin-top:6px;">
             <strong>ℹ️ Information only</strong>
             <p class="provider-meta" style="margin:6px 0 0;">This listing is for reference only and cannot be booked through Radius. Please contact the number above directly to arrange service.</p>
           </div>`
        : `<button class="btn btn-primary" onclick="startBooking('${p.id}')">Book This Pro</button>`}
    </div>

    <div class="card" style="margin-bottom:24px;">
      <h3 style="margin-top:0;">Location</h3>
      <div class="map-box">
        <iframe src="${mapEmbedUrl(p.lat, p.lng, p.name)}" loading="lazy" title="${p.name} location"></iframe>
      </div>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3 style="margin-top:0;">Services & pricing</h3>
        ${p.services.map(s=>`
          <div class="summary-row"><span>${s.name}</span><span class="price-tag">${fmt(s.price)}</span></div>
        `).join('')}
      </div>
      <div class="card">
        <h3 style="margin-top:0;">Reviews</h3>
        ${p.reviews.length ? p.reviews.map(r=>`
          <div class="review-item">
            <div style="display:flex; justify-content:space-between;">
              <strong>${r.name}</strong>
              <span class="stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</span>
            </div>
            <div class="provider-meta" style="margin:4px 0;">${r.date}</div>
            <div>${r.comment}</div>
          </div>
        `).join('') : `<div class="provider-meta">No reviews yet.</div>`}
      </div>
    </div>
  </div>`;
}

function startBooking(providerId){
  const prov = getProvider(providerId);
  if(prov && prov.category === 'phone'){
    toast('This listing is for information only — please call the provider directly.');
    return;
  }
  if(!DB.currentUserId){
    toast('Please log in to book a service');
    state.redirect = {view:'provider', params:{id:providerId}};
    nav('auth');
    return;
  }
  nav('booking',{providerId});
}

function viewBooking(params){
  const p = getProvider(params.providerId);
  if(!p) return `<div class="container section empty-state">Provider not found.</div>`;
  const today = new Date().toISOString().split('T')[0];
  return `
  <div class="container section" style="max-width:640px; margin:0 auto;">
    <div class="eyebrow">Step 1 of 3 · Booking details</div>
    <h2 style="margin-top:0;">Book ${p.name}</h2>
    <div class="card">
      <form onsubmit="return submitBooking(event,'${p.id}')">
        <div class="form-group">
          <label>Service</label>
          <select class="field" name="serviceIdx" required>
            ${p.services.map((s,i)=>`<option value="${i}">${s.name} — ${fmt(s.price)}</option>`).join('')}
          </select>
        </div>
        <div class="form-group" style="display:flex; gap:12px;">
          <div style="flex:1;">
            <label>Date</label>
            <input class="field" type="date" name="date" min="${today}" required />
          </div>
          <div style="flex:1;">
            <label>Time</label>
            <input class="field" type="time" name="time" required />
          </div>
        </div>
        <div class="form-group">
          <label>Street / House No.</label>
          <input class="field" name="street" placeholder="e.g. 12-34, Ring Road" required />
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label>Mandal</label>
            <select class="field" name="mandal" required>
              ${mandalsFor(p.area).map(m=>`<option value="${m}">${m}</option>`).join('') || `<option value="${p.area}">${p.area}</option>`}
            </select>
          </div>
          <div class="form-group">
            <label>Pincode</label>
            <input class="field" name="pincode" placeholder="e.g. 520010" pattern="[0-9]{6}" maxlength="6" required />
          </div>
        </div>
        <div class="form-group">
          <label>Notes for the provider (optional)</label>
          <input class="field" name="notes" placeholder="Anything they should know?" />
        </div>
        <button class="btn btn-primary btn-block" type="submit">Continue to Payment</button>
      </form>
    </div>
    <div class="card" style="margin-top:14px;">
      <h3 style="margin-top:0;">${p.name}'s location</h3>
      <p class="provider-meta">${p.street}, ${p.mandal}, ${p.area} - ${p.pincode}</p>
      <div class="map-box small">
        <iframe src="${mapEmbedUrl(p.lat, p.lng, p.name)}" loading="lazy" title="Provider location"></iframe>
      </div>
    </div>
  </div>`;
}

function submitBooking(e, providerId){
  e.preventDefault();
  const f = e.target;
  const p = getProvider(providerId);
  const service = p.services[Number(f.serviceIdx.value)];
  state.bookingDraft = {
    providerId,
    serviceName: service.name,
    servicePrice: service.price,
    date: f.date.value,
    time: f.time.value,
    street: f.street.value,
    mandal: f.mandal.value,
    pincode: f.pincode.value,
    address: f.street.value + ', ' + f.mandal.value + ' - ' + f.pincode.value,
    notes: f.notes.value,
  };
  state.paymentMethod = 'card';
  nav('payment',{providerId});
  return false;
}

function viewPayment(params){
  const p = getProvider(params.providerId);
  const d = state.bookingDraft;
  if(!p || !d) return `<div class="container section empty-state">Nothing to pay for yet. <a href="#" onclick="nav('search');return false;">Start a search</a></div>`;
  return `
  <div class="container section" style="max-width:640px; margin:0 auto;">
    <div class="eyebrow">Step 2 of 3 · Payment</div>
    <h2 style="margin-top:0;">Confirm and pay</h2>
    <div class="card" style="margin-bottom:18px;">
      <div class="summary-row"><span>Provider</span><span>${p.name}</span></div>
      <div class="summary-row"><span>Service</span><span>${d.serviceName}</span></div>
      <div class="summary-row"><span>Date & time</span><span>${d.date} · ${d.time}</span></div>
      <div class="summary-row"><span>Total</span><span>${fmt(d.servicePrice)}</span></div>
    </div>
    <div class="card">
      ${state.processingPayment ? `<div class="empty-state">${state.paymentMethod==='cod' ? 'Confirming your cash on delivery booking…' : 'Processing payment…'}</div>` : `
      <div class="pay-method-toggle">
        <button type="button" class="${state.paymentMethod==='card'?'active':''}" onclick="state.paymentMethod='card'; render();">💳 Card / Online</button>
        <button type="button" class="${state.paymentMethod==='cod'?'active':''}" onclick="state.paymentMethod='cod'; render();">💵 Cash on Delivery</button>
      </div>
      ${state.paymentMethod === 'card' ? `
      <form onsubmit="return submitPayment(event,'${p.id}')">
        <div class="form-group">
          <label>Name on card</label>
          <input class="field" name="nameOnCard" placeholder="Full name" required />
        </div>
        <div class="form-group">
          <label>Card number</label>
          <input class="field" name="cardNumber" placeholder="4242 4242 4242 4242" required maxlength="19" />
        </div>
        <div class="form-group" style="display:flex; gap:12px;">
          <div style="flex:1;">
            <label>Expiry</label>
            <input class="field" name="expiry" placeholder="MM/YY" required maxlength="5" />
          </div>
          <div style="flex:1;">
            <label>CVC</label>
            <input class="field" name="cvc" placeholder="123" required maxlength="4" />
          </div>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Pay ${fmt(d.servicePrice)}</button>
        <p class="provider-meta" style="text-align:center; margin-top:10px;">Demo payment form — no real transaction occurs.</p>
      </form>` : `
      <form onsubmit="return submitCodBooking(event,'${p.id}')">
        <div class="cod-note" style="margin-bottom:18px;">
          <span class="cod-icon">💵</span>
          <div>
            Pay <strong>${fmt(d.servicePrice)}</strong> in cash directly to ${p.name} after the service is completed at your doorstep. Please keep exact change ready if possible.
          </div>
        </div>
        <div class="form-group">
          <label>Contact number for delivery confirmation</label>
          <input class="field" name="codPhone" type="tel" placeholder="10-digit mobile number" pattern="[0-9]{10}" required />
        </div>
        <button class="btn btn-primary btn-block" type="submit">Confirm Cash on Delivery Booking</button>
        <p class="provider-meta" style="text-align:center; margin-top:10px;">No payment is collected now — you pay ${p.name} in person when the job is done.</p>
      </form>`}
      `}
    </div>
  </div>`;
}

function submitPayment(e, providerId){
  e.preventDefault();
  const f = e.target;
  if(!f.cardNumber.value.trim() || !f.expiry.value.trim() || !f.cvc.value.trim() || !f.nameOnCard.value.trim()){
    toast('Please fill in all payment fields');
    return false;
  }
  const cardLast4 = f.cardNumber.value.replace(/\D/g,'').slice(-4);
  state.processingPayment = true;
  render();
  setTimeout(()=>{
    finalizeBooking(providerId, {paymentMethod:'card', cardLast4});
  }, 900);
  return false;
}

function submitCodBooking(e, providerId){
  e.preventDefault();
  const f = e.target;
  if(!f.codPhone.value.trim()){
    toast('Please provide a contact number');
    return false;
  }
  state.processingPayment = true;
  render();
  setTimeout(()=>{
    finalizeBooking(providerId, {paymentMethod:'cod', codPhone:f.codPhone.value.trim()});
  }, 700);
  return false;
}

function finalizeBooking(providerId, paymentInfo){
  const d = state.bookingDraft;
  const booking = {
    id: 'BK-' + (1000 + DB.bookings.length + 1),
    userId: DB.currentUserId,
    providerId: providerId,
    serviceName: d.serviceName,
    servicePrice: d.servicePrice,
    date: d.date,
    time: d.time,
    street: d.street,
    mandal: d.mandal,
    pincode: d.pincode,
    address: d.address,
    notes: d.notes,
    paymentMethod: paymentInfo.paymentMethod,
    cardLast4: paymentInfo.cardLast4 || null,
    codPhone: paymentInfo.codPhone || null,
    paid: paymentInfo.paymentMethod === 'card',
    stage: 'paid',
    createdAt: new Date().toISOString(),
  };
  DB.bookings.push(booking);
  state.processingPayment = false;
  state.bookingDraft = null;
  toast(paymentInfo.paymentMethod === 'cod' ? 'Booking confirmed — pay cash on delivery' : 'Payment successful — booking confirmed');
  nav('status',{id:booking.id});
}

function viewStatus(params){
  const b = getBooking(params.id);
  if(!b) return `<div class="container section empty-state">Booking not found.</div>`;
  const p = getProvider(b.providerId);
  const u = currentUser();
  const stageLabels = {paid:'Payment Confirmed', accepted:'Provider Accepted', in_progress:'In Progress', completed:'Completed', reviewed:'Reviewed'};
  const stageLabelsCod = {paid:'Booking Confirmed', accepted:'Provider Accepted', in_progress:'In Progress', completed:'Completed', reviewed:'Reviewed'};
  const labels = b.paymentMethod === 'cod' ? stageLabelsCod : stageLabels;

  let controls = '';
  if(b.stage === 'paid'){
    controls = `<button class="btn btn-primary" onclick="advanceStage('${b.id}','accepted')">Simulate: Provider Accepts</button>`;
  } else if(b.stage === 'accepted'){
    controls = `<button class="btn btn-primary" onclick="advanceStage('${b.id}','in_progress')">Simulate: Start Service</button>`;
  } else if(b.stage === 'in_progress'){
    controls = `<button class="btn btn-primary" onclick="advanceStage('${b.id}','completed')">Simulate: Mark Completed</button>`;
  }

  const paymentBadge = b.paymentMethod === 'cod'
    ? `<span class="badge-stage dot" style="border-color:var(--accent-2); color:var(--accent-2);">💵 Cash on Delivery</span>`
    : `<span class="badge-stage dot">💳 Paid by card ${b.cardLast4 ? '···'+b.cardLast4 : ''}</span>`;

  let contactCard = '';
  if(['accepted','in_progress','completed','reviewed'].includes(b.stage)){
    contactCard = `<div class="card" style="margin-top:14px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
      <div>
        <div class="provider-name">${p.name}</div>
        <div class="provider-meta">📞 <a href="tel:${p.phone.replace(/\s/g,'')}">${p.phone}</a></div>
        ${b.paymentMethod==='cod' ? `<div class="provider-meta" style="margin-top:4px;">💵 Amount due on completion: <strong>${fmt(b.servicePrice)}</strong></div>` : ''}
      </div>
      <a class="btn btn-ghost btn-sm" href="tel:${p.phone.replace(/\s/g,'')}">Call Provider</a>
    </div>`;
  }

  /* --- Improved live tracking: clear customer <-> worker map with both pins,
     directional route, distance, and a readable progress bar with named endpoints --- */
  let trackingWidget = '';
  if(b.stage === 'in_progress'){
    const eta = typeof b.trackingETA === 'number' ? b.trackingETA : 0;
    const initial = b.trackingETAInitial || 15;
    const pct = Math.min(100, Math.round(((initial - eta) / initial) * 100));
    const arrived = eta <= 0;

    // Customer destination coords: derive from provider's city center with a stable per-booking jitter,
    // so the customer's booked address gets a distinct, consistent pin near the provider's service area.
    const cCenter = CITY_COORDS[p.area] || [16.5,80.6];
    const custLat = jitter(cCenter[0], b.id+'custlat');
    const custLng = jitter(cCenter[1], b.id+'custlng');
    const distKm = distanceKm(p.lat, p.lng, custLat, custLng).toFixed(1);

    trackingWidget = `
    <div class="card" style="margin-top:14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
        <span class="live-badge"><span class="live-dot"></span> Live Tracking</span>
        <span class="provider-meta mono">${b.id} · ${distKm} km</span>
      </div>

      <div class="map-box" style="margin-top:14px; height:240px;">
        <div class="map-legend">
          <div class="lg-row"><span class="lg-dot" style="background:var(--accent-2);"></span> ${p.name} (worker)</div>
          <div class="lg-row"><span class="lg-dot" style="background:var(--accent);"></span> You (customer)</div>
        </div>
        <iframe src="${mapDirectionsEmbedUrl(p.lat, p.lng, custLat, custLng)}" loading="lazy" title="Route from worker to customer"></iframe>
      </div>

      <div class="track-path">
        <span class="track-endpoint" style="left:-4px;" title="${p.name}">🔧</span>
        <span class="track-endpoint-label" style="left:-10px;">Worker</span>
        <div class="track-fill" style="width:${pct}%;"></div>
        <div class="track-marker" style="left:${pct}%;">🚗</div>
        <span class="track-endpoint" style="right:-4px;" title="You">🏠</span>
        <span class="track-endpoint-label" style="right:-14px;">You</span>
      </div>
      <div class="track-legend">
        <span>${pct}% of the way</span>
        <span>${arrived ? 'Arrived' : distKm + ' km away'}</span>
      </div>

      <p style="text-align:center; margin:20px 0 0;">
        ${!arrived
          ? `<strong>${p.name}</strong> is heading to your address — arriving in <strong>${eta} min</strong>`
          : `✅ <strong>${p.name}</strong> has arrived at ${b.address} and is working on your service`}
      </p>
    </div>`;
  }

  let reviewBlock = '';
  if(b.stage === 'completed'){
    reviewBlock = `
    <div class="card" style="margin-top:18px;">
      ${b.paymentMethod==='cod' ? `<div class="cod-note" style="margin-bottom:16px;"><span class="cod-icon">💵</span><div>Please pay <strong>${fmt(b.servicePrice)}</strong> cash directly to ${p.name} if you haven't already.</div></div>` : ''}
      <h3 style="margin-top:0;">Rate & review ${p.name}</h3>
      <form onsubmit="return submitReview(event,'${b.id}')">
        <div class="star-input" id="reviewStars">
          ${[1,2,3,4,5].map(n=>`<button type="button" class="star-btn ${n<=state.reviewStars?'filled':''}" onclick="clickStar(${n})">★</button>`).join('')}
        </div>
        <div class="form-group">
          <textarea class="field" name="comment" rows="3" placeholder="How did it go?" required></textarea>
        </div>
        <button class="btn btn-primary" type="submit">Submit Review</button>
      </form>
    </div>`;
  } else if(b.stage === 'reviewed'){
    const r = p.reviews[p.reviews.length-1];
    reviewBlock = `
    <div class="card" style="margin-top:18px;">
      <h3 style="margin-top:0;">Your review</h3>
      <div class="stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div>
      <p>${r.comment}</p>
      <button class="btn btn-ghost" onclick="nav('bookings')">Back to My Bookings</button>
    </div>`;
  }

  return `
  <div class="container section" style="max-width:680px; margin:0 auto;">
    <div class="eyebrow">Step 3 of 3 · Track your service</div>
    <h2 style="margin-top:0;">Booking ${b.id}</h2>
    <div class="card">
      <div class="summary-row"><span>Provider</span><span>${p.name}</span></div>
      <div class="summary-row"><span>Service</span><span>${b.serviceName}</span></div>
      <div class="summary-row"><span>Date & time</span><span>${b.date} · ${b.time}</span></div>
      <div class="summary-row"><span>Address</span><span>${b.address}</span></div>
      <div class="summary-row"><span>Payment</span><span>${paymentBadge}</span></div>
      <div class="summary-row"><span>Status</span><span class="badge-stage dot">${labels[b.stage]}</span></div>
      ${timeline(b.stage)}
      ${controls ? `<div style="text-align:center; margin-top:18px;">${controls}</div>` : ''}
    </div>
    ${contactCard}
    ${trackingWidget}
    ${reviewBlock}
  </div>`;
}

function advanceStage(bookingId, newStage){
  const b = getBooking(bookingId);
  b.stage = newStage;
  if(newStage === 'in_progress'){
    const eta = 8 + Math.floor(Math.random()*10);
    b.trackingETA = eta;
    b.trackingETAInitial = eta;
  }
  render();
  toast('Status updated: ' + newStage.replace('_',' '));
}

function clickStar(n){
  state.reviewStars = n;
  render();
}

function submitReview(e, bookingId){
  e.preventDefault();
  const f = e.target;
  const b = getBooking(bookingId);
  const p = getProvider(b.providerId);
  const u = currentUser();
  if(!state.reviewStars){
    toast('Please select a star rating');
    return false;
  }
  p.reviews.push({
    name: u ? u.name : 'Customer',
    rating: state.reviewStars,
    comment: f.comment.value,
    date: new Date().toISOString().split('T')[0],
  });
  p.reviewCount = (p.reviewCount || p.reviews.length) + 1;
  b.stage = 'reviewed';
  state.reviewStars = 0;
  toast('Thanks for your review!');
  render();
  return false;
}

