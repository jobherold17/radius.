/* ---------------- Views ---------------- */
function viewHome(){
  const top = [...DB.providers].sort((a,b)=>avgRating(b)-avgRating(a)).slice(0,3);
  return `
  <div class="container">
    <div class="hero">
      <div>
        <div class="eyebrow">Local services across Andhra Pradesh</div>
        <h1>Every trusted pro in your radius, one search away.</h1>
        <p class="sub">Find plumbers, electricians, tutors, cleaners, and more across Visakhapatnam, Vijayawada, Guntur, and beyond. Book a time, pay securely (card or cash), and track your service live from accepted to completed.</p>
        <form class="search-card" onsubmit="return doSearch(event)">
          <input class="field" type="text" id="homeQuery" placeholder="Search e.g. 'electrician', 'deep clean'..."
            value="${state.filterQuery || ''}"
            oninput="onHomeSearchInput(this.value)"
            onfocus="onHomeSearchInput(this.value)"
            onblur="hideSuggestSoon('home')" autocomplete="off" />
          <select class="field" id="homeCategory">
            <option value="">All services</option>
            ${categories.map(c=>`<option value="${c.id}">${c.icon} ${c.name}</option>`).join('')}
          </select>
          <select class="field" id="homeLocation">
            <option value="">All Andhra Pradesh</option>
            ${AP_CITIES.map(c=>`<option value="${c}">${c}</option>`).join('')}
          </select>
          <button class="btn btn-primary" type="submit">Find Pros</button>
          <div class="search-suggest" id="homeSuggestDropdown" style="display:${state.showHomeSuggest?'block':'none'}; top:calc(100% + 4px);">
            ${state.showHomeSuggest ? suggestDropdown('homeQuery','homeSuggestDropdown', state.filterQuery) : ''}
          </div>
        </form>
        <div class="stat-line">1,240+ verified pros across Andhra Pradesh · 4.8 average rating · live service tracking · cash or card</div>
        <button class="btn btn-ghost btn-sm" style="margin-top:14px;" onclick="nav('find-map')">📍 Find workers on the map</button>
      </div>
      <div>${orbitScene()}</div>
    </div>
  </div>

  <div class="container" style="padding-bottom:0;">
    <div class="card" style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap;">
      <div>
        <div class="eyebrow" style="margin-bottom:6px;">For skilled pros</div>
        <h3 style="margin:0 0 4px;">Are you a plumber, electrician, or tutor?</h3>
        <p class="provider-meta" style="margin:0;">Register as a worker, list your services, and get found by customers near your street and mandal.</p>
      </div>
      <button class="btn btn-primary" onclick="state.authTab='register'; state.authRole='worker'; nav('auth')">Register as a Worker</button>
    </div>
  </div>

  <div class="section container">
    <div class="eyebrow">Browse by service</div>
    <h2 style="margin-top:0;">What do you need help with?</h2>
    <div class="grid grid-4">
      ${categories.map(c=>`
        <div class="card category-card" onclick="selectCategory('${c.id}')">
          <span class="icon">${c.icon}</span>
          <span class="name">${c.name}</span>
        </div>`).join('')}
    </div>
  </div>

  <div class="section container" style="padding-top:0;">
    <div class="eyebrow">How booking works</div>
    <h2 style="margin-top:0;">From search to review, in five stops</h2>
    <div class="card">${timeline('none')}</div>
  </div>

  <div class="section container" style="padding-top:0;">
    <div class="eyebrow">Top rated</div>
    <h2 style="margin-top:0;">Highly rated near you</h2>
    <div class="grid grid-3">
      ${top.map(providerCard).join('')}
    </div>
  </div>
  `;
}

function providerCard(p){
  const c = catInfo(p.category);
  return `
  <div class="card provider-card">
    <div class="provider-top">
      ${avatarHtml(p.name, p.avatarUrl, 48, 15)}
      <div>
        <div class="provider-name">${p.name}</div>
        <div class="provider-meta">${c.icon} ${c.name} · ${p.area}</div>
      </div>
    </div>
    <div>${starsDisplay(avgRating(p))} <span class="provider-meta">(${reviewCountDisplay(p)})</span></div>
    <div class="price-tag">From ${fmt(Math.min(...p.services.map(s=>s.price)))}</div>
    <button class="btn btn-ghost btn-block" onclick="nav('provider',{id:'${p.id}'})">View Profile</button>
  </div>`;
}

function doSearch(e){
  e.preventDefault();
  const q = document.getElementById('homeQuery').value.trim();
  const cat = document.getElementById('homeCategory').value;
  const loc = document.getElementById('homeLocation').value.trim();
  state.filterQuery = q;
  state.filterCategory = cat;
  state.filterLocation = loc;
  nav('search');
  return false;
}

function selectCategory(id){
  state.filterCategory = id;
  state.filterLocation = '';
  state.filterQuery = '';
  nav('search');
}

function viewSearch(){
  const q = (state.filterQuery || '').trim().toLowerCase();
  let results = DB.providers.filter(p=>{
    const matchCat = !state.filterCategory || p.category === state.filterCategory;
    const matchLoc = !state.filterLocation || p.area.toLowerCase().includes(state.filterLocation.toLowerCase());
    const matchRating = !state.filterRating || avgRating(p) >= Number(state.filterRating);
    const c = catInfo(p.category);
    const matchQuery = !q ||
      p.name.toLowerCase().includes(q) ||
      c.name.toLowerCase().includes(q) ||
      p.area.toLowerCase().includes(q) ||
      p.bio.toLowerCase().includes(q) ||
      p.services.some(s=>s.name.toLowerCase().includes(q));
    return matchCat && matchLoc && matchRating && matchQuery;
  });
  if(state.sortBy === 'rating') results.sort((a,b)=>avgRating(b)-avgRating(a));
  if(state.sortBy === 'price') results.sort((a,b)=>Math.min(...a.services.map(s=>s.price)) - Math.min(...b.services.map(s=>s.price)));

  /* When there's a query, surface the exact matched service under each result so
     typing "leak" or "deep clean" clearly shows which service matched. */
  const matchedServiceFor = (p) => {
    if(!q) return null;
    return p.services.find(s=>s.name.toLowerCase().includes(q));
  };

  return `
  <div class="container section">
    <div class="eyebrow">Search results</div>
    <h2 style="margin-top:0; margin-bottom:20px;">Find your pro</h2>
    <div class="card" style="display:flex; gap:12px; flex-wrap:wrap; margin-bottom:24px; position:relative;">
      <input class="field" style="max-width:260px;" type="text" id="searchPageInput" placeholder="Search services or pros..." value="${state.filterQuery || ''}"
        oninput="state.filterQuery=this.value; document.getElementById('searchLiveResults').innerHTML=renderSearchResultsList();"
        autocomplete="off" />
      <select class="field" style="max-width:220px;" onchange="state.filterCategory=this.value; render();">
        <option value="">All services</option>
        ${categories.map(c=>`<option value="${c.id}" ${state.filterCategory===c.id?'selected':''}>${c.icon} ${c.name}</option>`).join('')}
      </select>
      <select class="field" style="max-width:220px;" onchange="state.filterLocation=this.value; render();">
        <option value="">All Andhra Pradesh</option>
        ${AP_CITIES.map(c=>`<option value="${c}" ${state.filterLocation===c?'selected':''}>${c}</option>`).join('')}
      </select>
      <select class="field" style="max-width:200px;" onchange="state.filterRating=this.value; render();">
        <option value="">All ratings</option>
        <option value="4" ${state.filterRating==='4'?'selected':''}>★★★★ & up (4+)</option>
        <option value="3" ${state.filterRating==='3'?'selected':''}>★★★ & up (3+)</option>
        <option value="2" ${state.filterRating==='2'?'selected':''}>★★ & up (2+)</option>
        <option value="1" ${state.filterRating==='1'?'selected':''}>★ & up (1+)</option>
      </select>
      <select class="field" style="max-width:200px;" onchange="state.sortBy=this.value; render();">
        <option value="rating" ${state.sortBy==='rating'?'selected':''}>Sort: Rating</option>
        <option value="price" ${state.sortBy==='price'?'selected':''}>Sort: Price (low to high)</option>
      </select>
    </div>
    <div id="searchLiveResults">${renderSearchResultsList()}</div>
  </div>`;
}

/* Renders the results grid based on current state — called on every keystroke in the search box
   so results update live as the user types, and shows which specific service matched. */
function renderSearchResultsList(){
  const q = (state.filterQuery || '').trim().toLowerCase();
  let results = DB.providers.filter(p=>{
    const matchCat = !state.filterCategory || p.category === state.filterCategory;
    const matchLoc = !state.filterLocation || p.area.toLowerCase().includes(state.filterLocation.toLowerCase());
    const matchRating = !state.filterRating || avgRating(p) >= Number(state.filterRating);
    const c = catInfo(p.category);
    const matchQuery = !q ||
      p.name.toLowerCase().includes(q) ||
      c.name.toLowerCase().includes(q) ||
      p.area.toLowerCase().includes(q) ||
      p.bio.toLowerCase().includes(q) ||
      p.services.some(s=>s.name.toLowerCase().includes(q));
    return matchCat && matchLoc && matchRating && matchQuery;
  });
  if(state.sortBy === 'rating') results.sort((a,b)=>avgRating(b)-avgRating(a));
  if(state.sortBy === 'price') results.sort((a,b)=>Math.min(...a.services.map(s=>s.price)) - Math.min(...b.services.map(s=>s.price)));

  if(!results.length){
    return `<div class="empty-state">No pros match those filters yet. Try a different service or area.</div>`;
  }

  return `<div class="grid grid-3">${results.map(p=>{
    const c = catInfo(p.category);
    const matched = q ? p.services.find(s=>s.name.toLowerCase().includes(q)) : null;
    return `
    <div class="card provider-card">
      <div class="provider-top">
        ${avatarHtml(p.name, p.avatarUrl, 48, 15)}
        <div>
          <div class="provider-name">${p.name}</div>
          <div class="provider-meta">${c.icon} ${c.name} · ${p.area}</div>
        </div>
      </div>
      <div>${starsDisplay(avgRating(p))} <span class="provider-meta">(${reviewCountDisplay(p)})</span></div>
      ${matched ? `<div class="tag" style="align-self:flex-start;">Matches: ${matched.name} · ${fmt(matched.price)}</div>` : ''}
      <div class="price-tag">From ${fmt(Math.min(...p.services.map(s=>s.price)))}</div>
      <button class="btn btn-ghost btn-block" onclick="nav('provider',{id:'${p.id}'})">View Profile</button>
    </div>`;
  }).join('')}</div>`;
}

