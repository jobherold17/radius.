function getProvider(id){ return DB.providers.find(p=>p.id===id); }
function getBooking(id){ return DB.bookings.find(b=>b.id===id); }
function currentUser(){ return DB.users.find(u=>u.id===DB.currentUserId) || null; }
function avgRating(provider){
  if(!provider.reviews.length) return 0;
  return provider.reviews.reduce((a,r)=>a+r.rating,0)/provider.reviews.length;
}
function reviewCountDisplay(provider){
  const c = provider.reviewCount || provider.reviews.length;
  return c > 999 ? (c/1000).toFixed(1).replace('.0','') + 'k' : c;
}
function starsDisplay(rating){
  const full = Math.round(rating);
  return '<span class="stars">' + '★'.repeat(full) + '☆'.repeat(5-full) + '</span>';
}
function fmt(n){ return '₹'+n; }

/* Renders a circular avatar — a profile photo (data URL) if provided, otherwise initials.
   Used for both customer/worker profile DPs and provider card avatars. */
function avatarHtml(name, avatarUrl, size, fontSize){
  size = size || 48; fontSize = fontSize || 15;
  if(avatarUrl){
    return `<div class="avatar" style="width:${size}px;height:${size}px;padding:0;overflow:hidden;background:var(--surface-2);">
      <img src="${avatarUrl}" alt="${name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />
    </div>`;
  }
  const initials = (name||'').split(' ').map(w=>w[0]).filter(Boolean).slice(0,2).join('');
  return `<div class="avatar" style="width:${size}px;height:${size}px;font-size:${fontSize}px;">${initials}</div>`;
}

/* Google Maps embed (no API key needed via the public /maps output=embed endpoint) */
function mapEmbedUrl(lat, lng, label, zoom){
  const q = encodeURIComponent(label || (lat+','+lng));
  return `https://maps.google.com/maps?q=${lat},${lng}(${q})&z=${zoom||14}&output=embed`;
}
function mapSearchEmbedUrl(query, zoom){
  return `https://maps.google.com/maps?q=${encodeURIComponent(query)}&z=${zoom||12}&output=embed`;
}
function mapDirectionsEmbedUrl(originLat, originLng, destLat, destLng){
  return `https://maps.google.com/maps?saddr=${originLat},${originLng}&daddr=${destLat},${destLng}&output=embed`;
}
function distanceKm(lat1,lng1,lat2,lng2){
  const R=6371, dLat=(lat2-lat1)*Math.PI/180, dLng=(lng2-lng1)*Math.PI/180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2;
  return R * 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

